// generated from rosidl_generator_c/resource/idl.h.em
// with input from sbg_driver:msg/SbgGpsPos.idl
// generated code does not contain a copyright notice

#ifndef SBG_DRIVER__MSG__SBG_GPS_POS_H_
#define SBG_DRIVER__MSG__SBG_GPS_POS_H_

#include "sbg_driver/msg/detail/sbg_gps_pos__struct.h"
#include "sbg_driver/msg/detail/sbg_gps_pos__functions.h"
#include "sbg_driver/msg/detail/sbg_gps_pos__type_support.h"

#endif  // SBG_DRIVER__MSG__SBG_GPS_POS_H_
