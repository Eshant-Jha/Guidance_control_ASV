// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SBG_DRIVER__MSG__SBG_GPS_VEL_HPP_
#define SBG_DRIVER__MSG__SBG_GPS_VEL_HPP_

#include "sbg_driver/msg/detail/sbg_gps_vel__struct.hpp"
#include "sbg_driver/msg/detail/sbg_gps_vel__builder.hpp"
#include "sbg_driver/msg/detail/sbg_gps_vel__traits.hpp"

#endif  // SBG_DRIVER__MSG__SBG_GPS_VEL_HPP_
