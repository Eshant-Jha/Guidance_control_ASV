// generated from rosidl_generator_c/resource/idl.h.em
// with input from sbg_driver:msg/SbgShipMotion.idl
// generated code does not contain a copyright notice

#ifndef SBG_DRIVER__MSG__SBG_SHIP_MOTION_H_
#define SBG_DRIVER__MSG__SBG_SHIP_MOTION_H_

#include "sbg_driver/msg/detail/sbg_ship_motion__struct.h"
#include "sbg_driver/msg/detail/sbg_ship_motion__functions.h"
#include "sbg_driver/msg/detail/sbg_ship_motion__type_support.h"

#endif  // SBG_DRIVER__MSG__SBG_SHIP_MOTION_H_
