// generated from rosidl_generator_c/resource/idl.h.em
// with input from sbg_driver:msg/SbgGpsHdt.idl
// generated code does not contain a copyright notice

#ifndef SBG_DRIVER__MSG__SBG_GPS_HDT_H_
#define SBG_DRIVER__MSG__SBG_GPS_HDT_H_

#include "sbg_driver/msg/detail/sbg_gps_hdt__struct.h"
#include "sbg_driver/msg/detail/sbg_gps_hdt__functions.h"
#include "sbg_driver/msg/detail/sbg_gps_hdt__type_support.h"

#endif  // SBG_DRIVER__MSG__SBG_GPS_HDT_H_
