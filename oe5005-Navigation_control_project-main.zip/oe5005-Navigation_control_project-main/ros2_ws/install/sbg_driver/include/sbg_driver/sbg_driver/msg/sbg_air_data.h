// generated from rosidl_generator_c/resource/idl.h.em
// with input from sbg_driver:msg/SbgAirData.idl
// generated code does not contain a copyright notice

#ifndef SBG_DRIVER__MSG__SBG_AIR_DATA_H_
#define SBG_DRIVER__MSG__SBG_AIR_DATA_H_

#include "sbg_driver/msg/detail/sbg_air_data__struct.h"
#include "sbg_driver/msg/detail/sbg_air_data__functions.h"
#include "sbg_driver/msg/detail/sbg_air_data__type_support.h"

#endif  // SBG_DRIVER__MSG__SBG_AIR_DATA_H_
