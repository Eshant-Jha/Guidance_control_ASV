// generated from rosidl_generator_c/resource/idl.h.em
// with input from sbg_driver:msg/SbgUtcTime.idl
// generated code does not contain a copyright notice

#ifndef SBG_DRIVER__MSG__SBG_UTC_TIME_H_
#define SBG_DRIVER__MSG__SBG_UTC_TIME_H_

#include "sbg_driver/msg/detail/sbg_utc_time__struct.h"
#include "sbg_driver/msg/detail/sbg_utc_time__functions.h"
#include "sbg_driver/msg/detail/sbg_utc_time__type_support.h"

#endif  // SBG_DRIVER__MSG__SBG_UTC_TIME_H_
