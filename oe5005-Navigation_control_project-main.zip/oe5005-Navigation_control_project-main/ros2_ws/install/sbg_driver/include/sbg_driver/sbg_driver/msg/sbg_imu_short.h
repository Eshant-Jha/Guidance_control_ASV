// generated from rosidl_generator_c/resource/idl.h.em
// with input from sbg_driver:msg/SbgImuShort.idl
// generated code does not contain a copyright notice

#ifndef SBG_DRIVER__MSG__SBG_IMU_SHORT_H_
#define SBG_DRIVER__MSG__SBG_IMU_SHORT_H_

#include "sbg_driver/msg/detail/sbg_imu_short__struct.h"
#include "sbg_driver/msg/detail/sbg_imu_short__functions.h"
#include "sbg_driver/msg/detail/sbg_imu_short__type_support.h"

#endif  // SBG_DRIVER__MSG__SBG_IMU_SHORT_H_
