// generated from rosidl_generator_c/resource/idl.h.em
// with input from sbg_driver:msg/SbgMag.idl
// generated code does not contain a copyright notice

#ifndef SBG_DRIVER__MSG__SBG_MAG_H_
#define SBG_DRIVER__MSG__SBG_MAG_H_

#include "sbg_driver/msg/detail/sbg_mag__struct.h"
#include "sbg_driver/msg/detail/sbg_mag__functions.h"
#include "sbg_driver/msg/detail/sbg_mag__type_support.h"

#endif  // SBG_DRIVER__MSG__SBG_MAG_H_
