// generated from rosidl_generator_c/resource/idl.h.em
// with input from interfaces:msg/Actuator.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__ACTUATOR_H_
#define INTERFACES__MSG__ACTUATOR_H_

#include "interfaces/msg/detail/actuator__struct.h"
#include "interfaces/msg/detail/actuator__functions.h"
#include "interfaces/msg/detail/actuator__type_support.h"

#endif  // INTERFACES__MSG__ACTUATOR_H_
