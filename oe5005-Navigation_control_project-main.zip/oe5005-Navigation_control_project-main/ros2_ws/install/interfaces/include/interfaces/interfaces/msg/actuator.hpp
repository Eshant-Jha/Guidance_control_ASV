// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__ACTUATOR_HPP_
#define INTERFACES__MSG__ACTUATOR_HPP_

#include "interfaces/msg/detail/actuator__struct.hpp"
#include "interfaces/msg/detail/actuator__builder.hpp"
#include "interfaces/msg/detail/actuator__traits.hpp"

#endif  // INTERFACES__MSG__ACTUATOR_HPP_
