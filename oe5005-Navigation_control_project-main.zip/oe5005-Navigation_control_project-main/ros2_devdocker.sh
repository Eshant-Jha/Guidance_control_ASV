docker build . -f .devcontainer/Dockerfile_ros2 -t abhilashiit/mav_simulator_ros2:1.0
