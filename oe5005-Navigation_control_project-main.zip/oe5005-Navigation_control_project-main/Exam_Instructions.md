# OE5005 Examination Instructions

In this exam you are going to program the guidance, navigation and control modules for the MAKRA (ONR Tumblehome) in ROS-2 architecture. You will be required to fill in your portions of the code in the file ```class_gnc.py```. This file is located in the folder ```/ros2_ws/src/gnc/gnc``` This class subscribes to sensors (IMU and UWB sensors and encoders). This class will be instantiated from the file ```start_gnc.py```. You do ***NOT*** need to edit anything outside of ```class_gnc.py```.

## Starting the simulator

It is presumed that you have docker on your desktop and hence the instructions to install docker are omitted here. Before you can begin, we need to build the docker image needed for the simulator to run. The docker image can be build with the following command executed at the root of the repository that you have cloned.

```
$ ./ros2_devdocker.sh
```
Once the build is complete, you can invoke the simulator with the command (again to be run at the root folder of the repository)

```
$ ./ros2_simulator.sh
```
You will see that this starts the simulator and it continuously prints out the states of the vehicle to the terminal. At the start you should see that the propeller and rudder commands must be zero and the vehicle will be at rest. However, you should see the time get incremented. 

## Starting your GNC package

Once the simulator is up and running, open another terminal and navigate to the root folder of the repository. Now execute the following command to start your GNC block to interact with the simulator.

```
$ ./ros2_gnc.sh
```
At the outset you will see that the terminal in which you ran the GNC package will also output the state of the vehicle. However, this is the state predicted from the Extended Kalman Filter. You will see that this does not change with time, even though your simulator should show that the propeller is getting up to speed of 800 RPM.

The Kalman Filter states will start showing after you program the correction step in the ```class_gnc.py``` file. If you do everything correctly (setting output matrices for IMU, UWB and encoders and program the EKF corrector equations), you should start to see that the states output to the screen by GNC block should show corrections as sensor information flows through the ros topics: ```/makara_00/imu_00```, ```/makara_00/uwb_01```, ```/makara_00/encoders_02```.

Once you have programmed your EKF, you will move on to the guidance and control algorithms in the ```guidance()``` and ```control()``` functions of the ```class_gnc.py``` file. If you implement the guidance and control correctly, you should see that the vehicle should track a square path specified in the file ```/inputs/makara_00.yml```. You will also see a score reported in the terminal output. This score will keep decreasing as you deviate from the path. If you programmed everything correctly, you should be able to track all the waypoints before the score reaches $0$.

## Note

Due to the need to maintain the problem statement to be tractable you will be only working with measurement updates and will not  be using a predictor in the EKF implementation. 

The EKF with quaternions is more complex and beyond the scope of this course. We will need multiplicative EKF (MEKF) in general that has not been discussed in the course. Therefore, we will implement the traditional EKF we have discussed in the course. But, since we will be using quaternions, we will not predict our states forward, but only update our states with measurements. Prediction will lead to instability as we do not handle the quaternion measurement updates in a consistent manner here.
    
The portions of the code that you need to edit or update has been marked specifically with instructions. Please do not edit the rest of the code without taking a backup.